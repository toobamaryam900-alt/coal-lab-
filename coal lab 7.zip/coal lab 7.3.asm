.model small
.data
num db 25
quotient db ?
remainder db ?

.code
mov ax,@data
mov ds,ax

mov al,num
mov bl,10
div bl        ; AL / BL

mov quotient,al
mov remainder,ah

mov ah,4ch
int 21h
end




