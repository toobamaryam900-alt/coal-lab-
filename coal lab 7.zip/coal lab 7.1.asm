.model small
.data
length db 5
width  db 4
area   db ?

.code
mov ax,@data
mov ds,ax

mov al,length
mov bl,width
mul bl        ; AL * BL

mov area,al   ; store result

mov ah,4ch
int 21h
end