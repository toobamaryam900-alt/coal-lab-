; Program to add two 8-bit numbers

.model small
.stack 100h
.data
    num1 db 25h        
    num2 db 17h       
    result db ?        

.code
main proc
    mov ax, @data
    mov ds, ax

    mov al, num1       
    add al, num2       
    mov result, al    

    mov ah, 4Ch       
    int 21h
main endp
end main




