; Program to print Name and SAP ID

.model small
.stack 100h
.data
    message db 'Name: Tooba', 0Dh, 0Ah
            db 'SAP ID: 70311', 0Dh, 0Ah, '$'

.code
main proc
    mov ax, @data
    mov ds, ax

    mov ah, 09h        
    lea dx, message    
    int 21h

    mov ah, 4Ch        
    int 21h
main endp
end main




