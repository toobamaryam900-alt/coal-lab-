.MODEL SMALL
.STACK 100H
.DATA
RESULT DB ?
.CODE
MAIN PROC
    MOV AX, @DATA
    MOV DS, AX

    MOV AL, 3
    MOV BL, 6
    ADD AL, BL       
    ADD AL, 30H
    MOV RESULT, AL

    MOV AH, 02H
    MOV DL, RESULT
    INT 21H

    MOV AH, 4CH
    INT 21H
MAIN ENDP
END MAIN




