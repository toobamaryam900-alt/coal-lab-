.model small
.stack 100h
.data

.code
main proc
    mov ax, @data
    mov ds, ax

    ; Print H
    mov dl, 'H'
    mov ah, 02h
    int 21h

    ; Print E
    mov dl, 'E'
    mov ah, 02h
    int 21h

    ; Print L
    mov dl, 'L'
    mov ah, 02h
    int 21h

    ; Print L
    mov dl, 'L'
    mov ah, 02h
    int 21h

    ; Print O
    mov dl, 'O'
    mov ah, 02h
    int 21h

    ; Exit program
    mov ah, 4Ch
    int 21h
main endp
end main